#!/bin/sh

[ -n "$DEFINE_COMMON_SH" ] && echo "already include" && return
DEFINE_COMMON_SH=common.sh

K_ERROR() {
	:
	echo "[x] $*"
	eslog -w -T 123 "[x] $*"
}

K_WARNNING() {
	:
	echo "[!] $*"
	eslog -w -T 123 "[!] $*"
}

K_INFO() {
	:
	echo "[=] $*"
}

K_DEBUG() {
	:
	#echo "[D] $*"
}

K_LOG() {
	:
	echo "[L] $*"
	eslog -w -T 123 "[=] $*"
}


SCRIPTS_DIR=/data/scripts
OBUID="123456"
OBUCODE="T"

sys_init() {
	OBUID=`getstring "/data/devconfig" ProductID 111111`

	case $OBUID in
		2*)
		OBUCODE="S"
		;;
		3*)
		OBUCODE="R"
		;;
		4*)
		OBUCODE="T"
		;;
		*)
		OBUCODE="T"
		;;
	esac
}

register_module() {
	if [ -f "$SCRIPTS_DIR/$*" ]; then
		sh "$SCRIPTS_DIR/$*" init
	else
		K_WARNNING "$* register_module(): Can't found this module"
	fi
}

start_module() {
	if [ -f "$SCRIPTS_DIR/$*" ]; then
		sh "$SCRIPTS_DIR/$*" start &
	else
		K_WARNNING "$* start_module(): Can't found this module"
	fi
}

stop_module() {
	if [ -f "$SCRIPTS_DIR/$*" ]; then
		sh "$SCRIPTS_DIR/$*" stop
	else
		K_WARNNING "$* stop_module(): Can't found this module"
	fi
}

kill_pid() {
	[ $# -ne 2 -o -z "$1" ] && K_INFO "Usage: kill_pid file name" && return 2
	
	[ ! -f "$1" ] && return 1
	
	pid=`getstring "$1" "$2" "0"`
	
	if [ $pid -ne 0 -a -d "/proc/$pid" ]; then
		kill -9 $pid
		return 0
	fi
	
	return 1
}

set_pid() {
	[ $# -ne 3 -o -z "$1" ] && K_INFO "Usage: set_pid file name pid" && return 2
	
	setstring "$1" "$2" "$3"	
}

check_pid() {
	[ $# -lt 2 -o -z "$1" ] && K_INFO "Usage: check_pid file name [pid]" && return 2
	
	[ ! -f "$1" ] && return 0
	
	pid=`getstring "$1" "$2" "0"`
	
	[ -n "$3" -a $pid -eq "$3" ] && return 0
	[ $pid -ne 0 -a -d "/proc/$pid" ] && echo $pid && return 1

	return 0
}

wait_signal() {
	[ $# -lt 2 ] && K_INFO "Usage: wait_signal fifo signal [block]" && return 1
	fifo=$1
	signal=$2
	block=$3
	
	if [ ! -p "$fifo" ]; then
		rm -rf $fifo >/dev/null 2>&1
		mkfifo $fifo
	fi
	
	while true; do
		while read SIGNAL; do
			case $SIGNAL in
			$signal*)
				return 0
				;;
			*)
				[ "X$block" != "X1" ] && return 1
				;;
			esac
		done < "$fifo"
	done
}

wait_timeout() {
	[ $# -ne 2 ] && K_INFO "Usage: wait_timeout pid sec" && return 1
	
	pid=$1
	timeout=$2
	sleep_sec=1
	
	until [ $timeout -lt 1 ]; do
		sleep $sleep_sec
		K_DEBUG sleep $sleep_sec, wait $pid
		[ ! -d "/proc/$pid" ] && return 0
		
		if [ $timeout -gt $sleep_sec ]; then
			timeout=`expr $timeout - $sleep_sec`
			sleep_sec=`expr $sleep_sec \* 2`
			[ $timeout -lt $sleep_sec ] && sleep_sec=$timeout
		else
			return 1
		fi
	done
	
	return 1
}


# init script system
sys_init
