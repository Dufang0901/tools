#!/bin/sh

[ ! -f "/data/scripts/common.sh" ] && echo "No user script wait to exec" && exit 0

. /data/scripts/common.sh

case "$1" in
	start|"")
		register_module wifi_upload
		register_module wifi_upgrade

		start_module wifi_upload
		start_module wifi_upgrade
		;;
	stop)
		stop_module wifi_upload
		stop_module wifi_upgrade
		;;
	*)	
		K_INFO "Usage: $0 start|stop"
		;;
esac
